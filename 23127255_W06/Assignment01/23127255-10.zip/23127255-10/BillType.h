#ifndef BILLTYPE_H
#define BILLTYPE_H

class BillType{
public:
	static const int TYPE_NORMAL = 0;
	static const int TYPE_GROWTH = 1;
};

#endif //BILLTYPE_H
